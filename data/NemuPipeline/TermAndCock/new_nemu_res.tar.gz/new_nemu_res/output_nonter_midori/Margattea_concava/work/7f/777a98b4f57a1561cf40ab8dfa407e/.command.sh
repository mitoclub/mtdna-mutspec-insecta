#!/bin/bash -ue
outfmt="6 saccver pident length qlen gapopen sstart send evalue bitscore sframe"

if [[ /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST == *nt ]]; then
	echo "INFO: Collecting relatives taxids" >&2
	if [[ "Margattea_concava" == Homo* ]]; then
		get_species_taxids.sh -t 9604 > genus.taxids
	else
		# TODO parse prepared table instead of fetching remote database. If table exist of course, make it general
		get_species_taxids.sh -t 1080994  > genus.taxids
	fi
	if [ `cat genus.taxids | wc -l` -eq 0 ]; then
		echo "Internal server error during fetching of genus taxids. Try again later" >&2
		exit 1
	fi
	sleep 2

	echo "INFO: Collecting species taxid information" >&2
	get_species_taxids.sh -n "Margattea_concava" | head -n 5 > sp_tax.info
	if [ `cat sp_tax.info | wc -l` -eq 0 ]; then
		echo "Internal server error during fetching of species taxa information. Try again later" >&2
		exit 1
	fi
	if [[ `grep "rank : species" sp_tax.info` ]]; then 
		raw_sp_taxid=`grep Taxid sp_tax.info`
		species_taxid="${raw_sp_taxid#*Taxid : }"
	fi
	sleep 1

	echo "INFO: Collecting under-species taxids" >&2
	get_species_taxids.sh -t $species_taxid > species.taxids
	if [ `cat species.taxids | wc -l` -eq 0 ]; then
		echo "Internal server error during fetching of species taxids. Try again later" >&2
		exit 1
	fi

	grep -v -f species.taxids genus.taxids > relatives.taxids

	echo "INFO: Checking number of taxids for outgroup" >&2
	if [ `cat relatives.taxids | wc -l` -eq 0 ]; then
		echo "ERROR: there are no taxids that can be used as outgroup." >&2
		echo "Maybe this species is single in the family, so pipeline can build incorrect phylogeneti tree" >&2
		echo "due to potential incorrect tree rooting. You can select sequences and outgroup manually and" >&2
		echo "run pipeline on your nucleotide sequences" >&2
		exit 1
	fi

	echo "INFO: Blasting species sequences in the nt" >&2
	tblastn -db /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST -db_gencode 5 -max_target_seqs 1000 			-query query_single.fasta -out blast_output_species.tsv -evalue 0.00001 			-num_threads 1 -taxidlist species.taxids 			-outfmt "$outfmt"

	echo "INFO: Filtering out bad hits: ident <= 80, query coverage <= 0.5" >&2
	awk '$2 > 80 && $3 / $4 > 0.5' blast_output_species.tsv > blast_output_species_filtered.tsv

	echo "INFO: Checking required number of hits" >&2
	nhits=`cat blast_output_species_filtered.tsv | wc -l`
	if [ $nhits -lt 3 ]; then
		echo "ERROR: there are only $nhits valuable hits in the Nucleotide collection for given query," >&2
		echo "but needed at least 3." >&2
		exit 1
	fi

	echo "INFO: Preparing coords for nucleotide sequences extraction" >&2
	# entry|range|strand, e.g. ID09 x-y minus
	awk '{print $1, $6, $7, ($NF ~ /^-/) ? "minus" : "plus"}' blast_output_species_filtered.tsv > raw_coords.txt
	awk '$2 > $3 {print $1, $3 "-" $2, $4}' raw_coords.txt > coords.txt
	awk '$3 > $2 {print $1, $2 "-" $3, $4}' raw_coords.txt >> coords.txt

	echo "INFO: Getting nucleotide sequences" >&2
	blastdbcmd -db /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST -entry_batch coords.txt -outfmt %f -out nucleotide_sequences.fasta

	echo "INFO: Checking required number of extracted seqs" >&2
	nseqs=`grep -c '>' nucleotide_sequences.fasta`
	if [ $nseqs -lt 3 ]; then
		echo "ERROR: cannot extract more than $nseqs seqs from the database for given query, but needed at least 3" >&2
		exit 1
	fi

	echo -e "INFO: Blasting for outgroup search" >&2
	tblastn -db /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST -db_gencode 5 -max_target_seqs 10 			-query query_single.fasta -out blast_output_genus.tsv -evalue 0.00001 			-num_threads 1 -taxidlist relatives.taxids 			-outfmt "$outfmt"
	
	echo "INFO: Filtering out bad hits: ident <= 70, query coverage <= 0.5" >&2
	awk '$2 > 70 && $3 / $4 > 0.5' blast_output_genus.tsv | sort -rk 9 > blast_output_genus_filtered.tsv

	echo "INFO: Checking required number of hits for outgroup" >&2
	if [ `cat blast_output_genus_filtered.tsv | wc -l` -eq 0 ]; then
		echo "ERROR: there are no hits in the database that could be used as outgroup." >&2
		echo "Unfortunately pipeline cannot analyse this species using nt databse." >&2
		exit 1
	fi

	echo "INFO: Preparing outgroup coords for nucleotide sequences extraction" >&2
	# entry|range|strand, e.g. ID09 x-y minus
	head -n 1 blast_output_genus_filtered.tsv | awk '{print $1, $6, $7, ($NF ~ /^-/) ? "minus" : "plus"}' > raw_coords_genus.txt
	awk '$2 > $3 {print $1, $3 "-" $2, $4}' raw_coords_genus.txt >  coords_genus.txt
	awk '$3 > $2 {print $1, $2 "-" $3, $4}' raw_coords_genus.txt >> coords_genus.txt

	echo "INFO: Getting nucleotide sequences of potential outgroups" >&2
	blastdbcmd -db /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST -entry_batch coords_genus.txt -outfmt %f -out outgroup_sequence.fasta
	
	echo "INFO: Sequences headers encoding" >&2
	ohead=`head -n 1 outgroup_sequence.fasta`
	cat outgroup_sequence.fasta nucleotide_sequences.fasta > sample.fasta
	multifasta_coding.py -a sample.fasta -g "${ohead:1}" -o sampled_sequences.fasta -m encoded_headers.txt

else
	report=report.blast
	nseqs=1000

	while true
	do   
		echo "INFO: Blasting in midori2 database; max_target_seqs=$nseqs" >&2
		tblastn -db /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST -db_gencode 5 -num_descriptions $nseqs -num_alignments $nseqs 				-query query_single.fasta -out $report -num_threads 1
		
		if [ `grep -c "No hits found" $report` -eq 0 ]; then 
			echo "INFO: some hits found in the database for given query" >&2
		else
			echo "ERROR: there are no hits in the database for given query" >&2
			exit 1
		fi

		if [ `grep -c "Margattea_concava" $report` -ge $((nseqs * 2 - 10)) ]; then
			nseqs=$((nseqs * 4))
			if [ $nseqs -gt 33000 ]; then
				echo "UNEXPECTED ERROR: database cannot contain more than 33000 sequences of one gene of some species" >&2
				exit 1
			fi
			echo "INFO: run blasting again due to abcence of different species; nseqs=$nseqs" >&2
		else
			echo "SUCCESS: other species for outgroup selection is in hits" >&2
			break
		fi
	done

	mview -in blast -out fasta $report 1>raw_sequences.fasta

	/opt/scripts_latest/header_sel_mod3.pl raw_sequences.fasta "Margattea_concava" 1>useless_seqs.fasta 2>headers_mapping.txt

	/opt/scripts_latest/nuc_coding_mod.pl headers_mapping.txt /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST 1>sampled_sequences.fasta

fi
