#!/bin/bash -ue
echo "Init query QC" >&2
if [ `grep -c ">" Panesthia_tryoni_CO1.fasta` -ne 1 ]; then
	echo "ERROR: Query fasta must contain single amino acid sequence" >&2
	exit 1
else
	echo "INFO: Number of sequences: `grep -c '>' Panesthia_tryoni_CO1.fasta`" >&2
fi

grep -v  ">" Panesthia_tryoni_CO1.fasta | grep -o . | sort | uniq -c | sort -nr > input_seq_char_counts.log
if [ `head -n 4 input_seq_char_counts.log | grep -Ec "[ACGT]"` -lt 4 ] || [ `grep -Ec "[EFILPQU]" input_seq_char_counts.log` -ne 0 ]; then
	echo "INFO: It's probably amino asid sequence" >&2
else
	echo "ERROR: Query fasta must contain single amino acid sequence" >&2
	exit 1
fi

mv Panesthia_tryoni_CO1.fasta query_single.fasta
