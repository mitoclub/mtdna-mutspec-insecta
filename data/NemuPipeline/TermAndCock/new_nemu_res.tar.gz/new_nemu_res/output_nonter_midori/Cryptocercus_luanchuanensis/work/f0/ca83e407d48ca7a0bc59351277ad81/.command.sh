#!/bin/bash -ue
nw_distance -m p -s f -n iqtree_shrinked.nwk | sort -grk 2 1> branches.txt

if [ `grep OUTGRP branches.txt | cut -f 2 | python3 -c "import sys; print(float(sys.stdin.readline().strip()) > 0)"` = False ]; then
	cat "branches.txt"
	echo "Something went wrong: outgroup is not furthest leaf in the tree" >&2
	exit 1
fi
