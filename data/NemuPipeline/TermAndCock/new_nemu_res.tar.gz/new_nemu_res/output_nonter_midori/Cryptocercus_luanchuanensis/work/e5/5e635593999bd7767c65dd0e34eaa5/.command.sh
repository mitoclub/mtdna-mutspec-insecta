#!/bin/bash -ue
nseqs=`grep -c ">" seqs_unique.fasta`
if [ $nseqs -lt 3 ]; then
	echo "ERROR: Pipeline requires at least 3 sequences, but received ${nseqs}" >&2
	exit 1
fi

if [ `grep -E -c ">OUTGRP" seqs_unique.fasta` -ne 1 ]; then
	echo "Unexpected error. Cannot find outgroup header in the alignment." >&2
	echo "Probably outgroup sequence for this gene cannot be found in the database." >&2
	exit 1
fi

grep -v  ">" seqs_unique.fasta | grep -o . | sort | uniq -c | sort -nr > char_numbers.log
if [ `head -n 5 char_numbers.log | grep -Ec "[ACGTacgt]"` -ge 3 ] && [ `grep -Ec "[EFILPQU]" char_numbers.log` -eq 0 ]; then
	echo "All right" >&2
else
	echo "Query fasta must contain nucleotides" >&2
	exit 1
fi

mv seqs_unique.fasta sequences.fasta
