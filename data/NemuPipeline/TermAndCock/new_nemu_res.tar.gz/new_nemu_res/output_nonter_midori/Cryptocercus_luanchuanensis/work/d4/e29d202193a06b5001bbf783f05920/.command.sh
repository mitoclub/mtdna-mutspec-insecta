#!/bin/bash -ue
/opt/scripts_latest/codon_alig_unique.pl sampled_sequences.fasta 1>seqs_unique.fasta
