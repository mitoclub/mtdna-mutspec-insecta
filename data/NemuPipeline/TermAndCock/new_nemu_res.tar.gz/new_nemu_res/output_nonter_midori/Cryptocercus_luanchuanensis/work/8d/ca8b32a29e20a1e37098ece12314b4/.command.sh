#!/bin/bash -ue
nw_labels -I iqtree_shrinked_rooted.nwk | sed 's/$/$/' > leaves.txt
select_records.py -f leaves.txt --fmt fasta msa_nuc.fasta msa_filtered.fasta

iqtree2 -te iqtree_shrinked_rooted.nwk -s msa_filtered.fasta -m GTR+FO+G6+I -asr -nt 1 --prefix anc 
if [ ! -f anc.rate ]; then
	touch anc.rate
fi
mv anc.rate rates.tsv
mv anc.iqtree iqtree_anc_report.log
mv anc.log iqtree_anc.log
nw_reroot anc.treefile OUTGRP | sed 's/;/ROOT;/' > final_tree.nwk

iqtree_states_add_part.py anc.state iqtree_anc.state
