#!/bin/bash -ue
alignment2iqtree_states.py msa_nuc.fasta leaves_states.state
