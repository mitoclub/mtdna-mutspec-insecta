#!/bin/bash -ue
nw_reroot -l iqtree_shrinked.nwk OUTGRP 1>iqtree_shrinked_rooted.nwk
