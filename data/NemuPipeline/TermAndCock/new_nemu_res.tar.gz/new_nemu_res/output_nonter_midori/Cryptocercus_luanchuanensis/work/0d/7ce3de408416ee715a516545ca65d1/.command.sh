#!/bin/bash -ue
if [[ /db/MIDORI2_UNIQ_NUC_SP_GB263_CO1_BLAST == *nt ]]; then
	mafft --thread 1 sequences.fasta > seqM.fa
	sed '/^>/!s/[actg]/\U&/g' seqM.fa > seqMU.fa
	goalign clean seqs -c 0.3 -i seqMU.fa -o seqMC.fa
	goalign clean sites -c 0.05 -i seqMC.fa -o seqMCC.fa
	seqkit rmdup -s < seqMCC.fa > seq_dd.fa
	java -jar /opt/macse_v2.07.jar -prog alignSequences -seq seq_dd.fa 		-gc_def 5 -optim 2 -max_refine_iter 0 -ambi_OFF
	
	java -jar /opt/macse_v2.07.jar -prog exportAlignment 		-align seq_dd_NT.fa -gc_def 5 -ambi_OFF 		-codonForInternalStop "NNN" -codonForFinalStop "---" 		-codonForInternalFS "NNN" -codonForExternalFS "---" 		-out_stat_per_seq macse_stat_per_seq.csv -out_stat_per_site macse_stat_per_site.csv 

	sed 's/!/n/g' seq_dd_NT_NT.fa > seq_dd_NT_FS.fa
	goalign clean sites -c 0.05 -i seq_dd_NT_FS.fa -o seq_dd_NT_FS_clean.fa
	seqkit rmdup -s < seq_dd_NT_FS_clean.fa > msa_nuc_lower.fasta
	sed '/^>/!s/[actg]/\U&/g' msa_nuc_lower.fasta > msa_nuc.fasta

else
	# NT2AA
	java -jar /opt/macse_v2.07.jar -prog translateNT2AA -seq sequences.fasta 		-gc_def 5 -out_AA translated.faa
	#ALN AA
	mafft --thread 1 translated.faa > translated_aln.faa
	#AA_ALN --> NT_ALN
	java -jar /opt/macse_v2.07.jar -prog reportGapsAA2NT 		-align_AA translated_aln.faa -seq sequences.fasta -out_NT aln.fasta
	echo "Do quality control" >&2
	/opt/scripts_latest/macse2.pl aln.fasta msa_nuc.fasta

	cp translated_aln.faa seq_dd_AA.fa
fi
