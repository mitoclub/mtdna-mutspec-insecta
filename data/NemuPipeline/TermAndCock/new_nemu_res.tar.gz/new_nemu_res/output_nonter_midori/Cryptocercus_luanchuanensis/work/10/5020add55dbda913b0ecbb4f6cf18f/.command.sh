#!/bin/bash -ue
if [ false = true ]; then 
	collect_mutations.py --tree final_tree.nwk --states iqtree_anc.state --states leaves_states.state 		--gencode 5 --syn --syn4f  		--proba --no-mutspec --pcutoff 0.3 		--mnum192 16 --outdir mout  --phylocoef 		--rates rates.tsv --cat-cutoff 1
else
	collect_mutations.py --tree final_tree.nwk --states iqtree_anc.state --states leaves_states.state 		--gencode 5 --syn --syn4f  		--proba --no-mutspec --pcutoff 0.3 		--mnum192 16 --outdir mout  --phylocoef
fi
mv mout/* .
mv mutations.tsv observed_mutations.tsv
mv run.log mut_extraction.log
