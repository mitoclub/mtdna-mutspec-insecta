#!/bin/bash -ue
nmuts=`cat observed_mutations.tsv | wc -l`
if [ $nmuts -lt 2 ]; then
	echo "ERROR: There are no reconstructed mutations after pipeline execution." >&2
	echo "Unfortunately this gene cannot be processed authomatically on available data." >&2
	exit 1
fi

calculate_mutspec.py -b observed_mutations.tsv -e expected_freqs.tsv -o . 	--exclude OUTGRP,ROOT --mnum192 16 --proba 	--proba_cutoff 0.3 --plot -x pdf 	--syn --syn4f  

if [ false = true ]; then
	calculate_mutspec.py -b observed_mutations.tsv -e expected_freqs.tsv -o .         --exclude OUTGRP,ROOT --mnum192 16 --proba 		--proba_cutoff 0.3 --plot -x pdf --subset internal 		--syn --syn4f  
	rm mean_expexted_mutations_internal.tsv
fi
if [ false = true ]; then
	calculate_mutspec.py -b observed_mutations.tsv -e expected_freqs.tsv -o .         --exclude OUTGRP,ROOT --mnum192 16 --proba 		--proba_cutoff 0.3 --plot -x pdf --subset terminal 		--syn --syn4f  
	rm mean_expexted_mutations_terminal.tsv
fi
if [ false = true ]; then
	calculate_mutspec.py -b observed_mutations.tsv -e expected_freqs.tsv -o .         --exclude OUTGRP,ROOT --mnum192 16 --proba 		--proba_cutoff 0.3 --branches 		--syn --syn4f  
fi
