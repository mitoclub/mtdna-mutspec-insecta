#!/bin/bash -ue
iqtree2 -s msa_nuc.fasta -m GTR+FO+G6+I -nt 1 --prefix phylo
mv phylo.treefile iqtree.nwk
mv phylo.iqtree iqtree_report.log
mv phylo.log iqtree.log
