#!/bin/bash -ue
if [ true = true ] && [ `nw_stats iqtree.nwk | grep leaves | cut -f 2` -gt 8 ]; then
	run_treeshrink.py -t iqtree.nwk -O treeshrink -o . -q 0.1 -x OUTGRP
	mv treeshrink.nwk iqtree_shrinked.nwk
	mv treeshrink_summary.txt iqtree_treeshrink.log
	mv treeshrink.txt iqtree_pruned_nodes.log
else
	cat iqtree.nwk > iqtree_shrinked.nwk
	if [ true = true ]; then
		echo "Shrinking are useless on such a small number of sequences" > iqtree_treeshrink.log
	fi
fi
