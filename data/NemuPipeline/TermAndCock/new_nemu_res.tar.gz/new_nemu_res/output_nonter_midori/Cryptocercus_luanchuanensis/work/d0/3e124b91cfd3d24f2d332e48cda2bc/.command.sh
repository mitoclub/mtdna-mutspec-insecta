#!/bin/bash -ue
nstops=`grep -Eo "\*[A-Za-z]" seq_dd_AA.fa | wc -l`
nseqs_aa=`grep -c ">" seq_dd_AA.fa`
thr_for_nstops=$((nseqs_aa * 2)) # num of seqs * 2 is the max number of stops
if [ $nstops -gt $thr_for_nstops ]; then
	echo "There are stops in ${nstops} sequences. It's possible that you set incorrect gencode" >&2
	exit 1
fi

nseqs=`grep -c ">" msa_nuc.fasta`
if [ $nseqs -lt 3 ]; then
	echo "ERROR: Too low number of sequences! Pipeline requires at least 3 sequences, but after deduplication left only ${nseqs}" >&2
	exit 1
fi
